"""Simple modular Streamlit app."""
